
const goods_cards = document.querySelector('.goods_cards');
console.log (goods_cards);


const card1 = document.querySelector('#card1');
card1.addEventListener('click', () => {
    const cartItems = document.querySelector('.cartItems');cartItems.style.display="block";
    const benefits = document.querySelector('.benefits');
    benefits.insertAdjacentHTML('afterEnd', `
    <div class="cartItems" style="display: none;">
        <div class=" mango1">
            <img class="shadow" src="img/mango pic 1.png">
            <div class="content">
                <div class="header_items">
                    <h1 class="mango1Header">
                        MANGO PEOPLE T-SHIRT
                    </h1>
                    <img src="img/Vector.png" id="close1">
                </div>
                <div class="textContent">
                    <div class="prices">
                        <p class="mango1Price">
                            Price: </p>
                        <p class="dollars">$300</p>
                    </div>
                    <p class="mango1Color">
                        Color: Red
                    </p>
                    <p class="mango1Size">
                        Size: Xl
                    </p>
                    <p class="mango1Quantity">
                        Quantity: <input class="card_input" type="number" style="margin-left: 24px;" value="2" /> </p>
                </div>
            </div>
        </div>
    </div>

    `)
});

const close1 = document.querySelector('#close1');
close1.addEventListener ('click', () => {
    const cartItems = document.querySelector('.cartItems');
    cartItems.remove();
})

const card2 = document.querySelector('#card2');
card2.addEventListener('click', () => {
    const cartItems2 = document.querySelector('.cartItems2');cartItems2.style.display="block";
    const benefits = document.querySelector('.benefits');
    benefits.insertAdjacentHTML('afterEnd', `
    <div class="cartItems2" style="display: none;">
        <div class=" mango1">
            <img class="shadow" src="img/mango pic 2 .png">
            <div class="content">
                <div class="header_items">
                    <h1 class="mango1Header">
                        MANGO PEOPLE T-SHIRT
                    </h1>
                    <img src="img/Vector.png" id="close2">
                </div>
                <div class="textContent">
                    <div class="prices">
                        <p class="mango1Price">
                            Price: </p>
                        <p class="dollars">$300</p>
                    </div>
                    <p class="mango1Color">
                        Color: Red
                    </p>
                    <p class="mango1Size">
                        Size: Xl
                    </p>
                    <p class="mango1Quantity">
                        Quantity: <input class="card_input" type="number" style="margin-left: 24px;" value="2" /> </p>
                </div>
            </div>
        </div>
    </div>

    `)
});

const close2 = document.querySelector('#close2');
close2.addEventListener ('click', () => {
    const cartItems2 = document.querySelector('.cartItems2');
    cartItems2.remove();
});


const card3 = document.querySelector('#card3');
card3.addEventListener('click', () => {
    const cartItems3 = document.querySelector('.cartItems3');cartItems3.style.display="block";
    const benefits = document.querySelector('.benefits');
    benefits.insertAdjacentHTML('afterEnd', `
    <div class="cartItems3" style="display: none;">
        <div class=" mango1">
            <img class="shadow" src="img/Rectangle 15 copy.png">
            <div class="content">
                <div class="header_items">
                    <h1 class="mango1Header">
                        MANGO PEOPLE T-SHIRT
                    </h1>
                    <img src="img/Vector.png" id="close3">
                </div>
                <div class="textContent">
                    <div class="prices">
                        <p class="mango1Price">
                            Price: </p>
                        <p class="dollars">$300</p>
                    </div>
                    <p class="mango1Color">
                        Color: Red
                    </p>
                    <p class="mango1Size">
                        Size: Xl
                    </p>
                    <p class="mango1Quantity">
                        Quantity: <input class="card_input" type="number" style="margin-left: 24px;" value="2" /> </p>
                </div>
            </div>
        </div>
    </div>

    `)
});

const close3 = document.querySelector('#close3');
close3.addEventListener ('click', () => {
    const cartItems3 = document.querySelector('.cartItems3');
    cartItems3.remove();
});

const card4 = document.querySelector('#card4');
card4.addEventListener('click', () => {
    const cartItems4 = document.querySelector('.cartItems4');cartItems4.style.display="block";
    const benefits = document.querySelector('.benefits');
    benefits.insertAdjacentHTML('afterEnd', `
    <div class="cartItems4" style="display: none;">
        <div class=" mango1">
            <img class="shadow" src="img/Rectangle 15 copy.png">
            <div class="content">
                <div class="header_items">
                    <h1 class="mango1Header">
                        MANGO PEOPLE T-SHIRT
                    </h1>
                    <img src="img/Vector.png" id="close4">
                </div>
                <div class="textContent">
                    <div class="prices">
                        <p class="mango1Price">
                            Price: </p>
                        <p class="dollars">$300</p>
                    </div>
                    <p class="mango1Color">
                        Color: Red
                    </p>
                    <p class="mango1Size">
                        Size: Xl
                    </p>
                    <p class="mango1Quantity">
                        Quantity: <input class="card_input" type="number" style="margin-left: 24px;" value="2" /> </p>
                </div>
            </div>
        </div>
    </div>

    `)
});

const close4 = document.querySelector('#close4');
close4.addEventListener ('click', () => {
    const cartItems4 = document.querySelector('.cartItems4');
    cartItems4.remove();
});


const card5 = document.querySelector('#card5');
card5.addEventListener('click', () => {
    const cartItems5 = document.querySelector('.cartItems5');cartItems5.style.display="block";
    const benefits = document.querySelector('.benefits');
    benefits.insertAdjacentHTML('afterEnd', `
    <div class="cartItems5" style="display: none;">
        <div class=" mango1">
            <img class="shadow" src="img/mango pic 5.1.png">
            <div class="content">
                <div class="header_items">
                    <h1 class="mango1Header">
                        MANGO PEOPLE T-SHIRT
                    </h1>
                    <img src="img/Vector.png" id="close5">
                </div>
                <div class="textContent">
                    <div class="prices">
                        <p class="mango1Price">
                            Price: </p>
                        <p class="dollars">$300</p>
                    </div>
                    <p class="mango1Color">
                        Color: Red
                    </p>
                    <p class="mango1Size">
                        Size: Xl
                    </p>
                    <p class="mango1Quantity">
                        Quantity: <input class="card_input" type="number" style="margin-left: 24px;" value="2" /> </p>
                </div>
            </div>
        </div>
    </div>

    `)
});

const close5 = document.querySelector('#close5');
close5.addEventListener ('click', () => {
    const cartItems5 = document.querySelector('.cartItems5');
    cartItems5.remove();
});


const card6 = document.querySelector('#card6');
card6.addEventListener('click', () => {
    const cartItems6 = document.querySelector('.cartItems6');cartItems6.style.display="block";
    const benefits = document.querySelector('.benefits');
    benefits.insertAdjacentHTML('afterEnd', `
    <div class="cartItems5" style="display: none;">
        <div class=" mango1">
            <img class="shadow" src="img/mango pic 5.1.png">
            <div class="content">
                <div class="header_items">
                    <h1 class="mango1Header">
                        MANGO PEOPLE T-SHIRT
                    </h1>
                    <img src="img/Vector.png" id="close5">
                </div>
                <div class="textContent">
                    <div class="prices">
                        <p class="mango1Price">
                            Price: </p>
                        <p class="dollars">$300</p>
                    </div>
                    <p class="mango1Color">
                        Color: Red
                    </p>
                    <p class="mango1Size">
                        Size: Xl
                    </p>
                    <p class="mango1Quantity">
                        Quantity: <input class="card_input" type="number" style="margin-left: 24px;" value="2" /> </p>
                </div>
            </div>
        </div>
    </div>

    `)
});

const close6 = document.querySelector('#close6');
close6.addEventListener ('click', () => {
    const cartItems6 = document.querySelector('.cartItems6');
    cartItems6.remove();
});


