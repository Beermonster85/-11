const cards = `
[
{
    "img": "img/Pic 1.png",
    "title": "ELLERY X M'O CAPSULE",
    "text": "Known for her sculptural takes on&nbsp;traditional tailoring, Australian arbiter of&nbsp;cool Kym Ellery teams up&nbsp;with Moda Operandi.",
    "price": "52.00"
},
{
    "img": "img/Pic 2.png",
    "title": "ELLERY X M'O CAPSULE",
    "text": "Known for her sculptural takes on&nbsp;traditional tailoring, Australian arbiter of&nbsp;cool Kym Ellery teams up&nbsp;with Moda Operandi.",
    "price": "52.00"
},

{
    "img": "img/Pic 3.png",
    "title": "ELLERY X M'O CAPSULE",
    "text": "Known for her sculptural takes on&nbsp;traditional tailoring, Australian arbiter of&nbsp;cool Kym Ellery teams up&nbsp;with Moda Operandi.",
    "price": "52.00"
},

{
    "img": "img/Pic 4.png",
    "title": "ELLERY X M'O CAPSULE",
    "text": "Known for her sculptural takes on&nbsp;traditional tailoring, Australian arbiter of&nbsp;cool Kym Ellery teams up&nbsp;with Moda Operandi.",
    "price": "52.00"
},
{
    "img": "img/Pic 5.png",
    "title": "ELLERY X M'O CAPSULE",
    "text": "Known for her sculptural takes on&nbsp;traditional tailoring, Australian arbiter of&nbsp;cool Kym Ellery teams up&nbsp;with Moda Operandi.",
    "price": "52.00"
},

{
    "img": "img/Pic 6.png",
    "title": "ELLERY X M'O CAPSULE",
    "text": "Known for her sculptural takes on&nbsp;traditional tailoring, Australian arbiter of&nbsp;cool Kym Ellery teams up&nbsp;with Moda Operandi.",
    "price": "52.00"
}
]
`;